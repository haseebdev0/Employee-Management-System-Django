# employees/views.py
from django.http import HttpResponse
from reportlab.pdfgen import canvas
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .models import Employee, Attendance, LeaveRequest, EmployeeReport
from django.contrib import messages
from django.utils import timezone
from django.core.files.storage import FileSystemStorage
from django.http import FileResponse
from django.contrib.auth.models import User
from django.db.models import Q, Avg, Count
from django.core.exceptions import ObjectDoesNotExist
from datetime import datetime, timedelta
import math


def home(request):
    return redirect('view_employees')

@login_required
def add_employee(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        salary = request.POST.get('salary') or '0.00'

        if User.objects.filter(username=username).exists():
            messages.error(request, 'Username already exists. Please choose a different username.')
            return render(request, 'employees/add_employee.html', {
                'employee_id': request.POST.get('employee_id'),
                'position': request.POST.get('position'),
                'department': request.POST.get('department'),
                'contact': request.POST.get('contact'),
                'salary': salary,
                'username': username
            })

        user = User.objects.create_user(username=username, password=password)
        Employee.objects.create(
            user=user,
            employee_id=request.POST.get('employee_id'),
            position=request.POST.get('position'),
            department=request.POST.get('department'),
            contact=request.POST.get('contact'),
            salary=salary
        )
        messages.success(request, 'Employee account created successfully. The employee can now login using the provided credentials.')
        return redirect('view_employees')
    return render(request, 'employees/add_employee.html')

@login_required
def update_employee(request, emp_id):
    employee = Employee.objects.get(id=emp_id)
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        employee.position = request.POST.get('position')
        employee.department = request.POST.get('department')
        employee.contact = request.POST.get('contact')
        employee.salary = request.POST.get('salary') or employee.salary

        if username and username != employee.user.username:
            if User.objects.filter(username=username).exclude(pk=employee.user.pk).exists():
                messages.error(request, 'Username already exists. Please choose a different username.')
                return render(request, 'employees/update_employee.html', {'employee': employee})
            employee.user.username = username

        if password:
            employee.user.set_password(password)

        employee.user.save()
        employee.save()
        messages.success(request, 'Employee profile and login credentials updated successfully.')
        return redirect('view_employees')
    return render(request, 'employees/update_employee.html', {'employee': employee})

@login_required
def delete_employee(request, emp_id):
    employee = Employee.objects.get(id=emp_id)
    employee.delete()
    return redirect('view_employees')

@login_required
def view_employees(request):
    query = request.GET.get('q', '')
    dept = request.GET.get('department', '')
    pos = request.GET.get('position', '')
    
    employees = Employee.objects.all()
    if query:
        employees = employees.filter(
            Q(employee_id__icontains=query) |
            Q(user__username__icontains=query) |
            Q(user__first_name__icontains=query) |
            Q(user__last_name__icontains=query)
        )
    if dept:
        employees = employees.filter(department=dept)
    if pos:
        employees = employees.filter(position=pos)
        
    departments = Employee.objects.values_list('department', flat=True).distinct()
    positions = Employee.objects.values_list('position', flat=True).distinct()
    
    return render(request, 'employees/view_employees.html', {
        'employees': employees,
        'departments': departments,
        'positions': positions,
        'query': query,
        'dept': dept,
        'pos': pos
    })

@login_required
def mark_attendance(request):
    if not request.user.is_superuser:
        return redirect('home')
        
    if request.method == 'POST':
        employee_id = request.POST.get('employee_id')
        action = request.POST.get('action')
        
        try:
            employee = Employee.objects.get(id=employee_id)
            if action == 'check_in':
                already_in = Attendance.objects.filter(employee=employee, check_out__isnull=True).last()
                if already_in:
                    messages.warning(request, f"{employee.user.username} is already checked in.")
                else:
                    Attendance.objects.create(employee=employee, check_in=timezone.now())
                    messages.success(request, f"Successfully checked in {employee.user.username}.")
            elif action == 'check_out':
                attendance = Attendance.objects.filter(employee=employee, check_out__isnull=True).last()
                if attendance:
                    attendance.check_out = timezone.now()
                    attendance.save()
                    messages.success(request, f"Successfully checked out {employee.user.username}.")
                else:
                    messages.warning(request, f"{employee.user.username} is not checked in.")
        except Employee.DoesNotExist:
            messages.error(request, "Employee not found.")
            
        return redirect('view_attendance')
        
    employees = Employee.objects.all()
    return render(request, 'employees/mark_attendance.html', {'employees': employees})

@login_required
def view_attendance(request):
    query = request.GET.get('q', '')
    date_str = request.GET.get('date', '')
    
    attendances = Attendance.objects.all().order_by('-date', '-check_in')
    
    if query:
        attendances = attendances.filter(
            Q(employee__employee_id__icontains=query) |
            Q(employee__user__username__icontains=query) |
            Q(employee__user__first_name__icontains=query) |
            Q(employee__user__last_name__icontains=query)
        )
        
    if date_str:
        try:
            filter_date = datetime.strptime(date_str, '%Y-%m-%d').date()
            attendances = attendances.filter(date=filter_date)
        except ValueError:
            pass
            
    return render(request, 'employees/view_attendance.html', {
        'attendances': attendances,
        'query': query,
        'date_str': date_str
    })





@login_required
def employee_profile(request):
    try:
        employee = request.user.employee
    except ObjectDoesNotExist:
        messages.error(request, 'No employee profile found for this user.')
        return redirect('home')
    leave_requests = LeaveRequest.objects.filter(employee=employee)
    attendances = Attendance.objects.filter(employee=employee)

    # POST Request Handling
    if request.method == 'POST':
        # Leave Request Submission
        if 'leave_request' in request.POST:
            start_date = request.POST.get('start_date')
            end_date = request.POST.get('end_date')
            reason = request.POST.get('reason')
            attachment = request.FILES.get('attachment')
            
            LeaveRequest.objects.create(
                employee=employee,
                start_date=start_date,
                end_date=end_date,
                reason=reason,
                attachment=attachment
            )
            messages.success(request, 'Leave application submitted!')

        # Attendance Check-In
        elif 'check_in' in request.POST:
            Attendance.objects.create(employee=employee, check_in=timezone.now())
            messages.success(request, 'Checked in successfully!')

        # Attendance Check-Out
        elif 'check_out' in request.POST:
            attendance = Attendance.objects.filter(
                employee=employee, 
                check_out__isnull=True
            ).last()
            if attendance:
                attendance.check_out = timezone.now()
                attendance.save()
                messages.success(request, 'Checked out successfully!')

        # Profile Picture Upload
        elif 'profile_pic' in request.FILES:
            profile_pic = request.FILES['profile_pic']
            fs = FileSystemStorage()
            filename = fs.save(f'profile_pics/{profile_pic.name}', profile_pic)
            employee.profile_picture = filename
            employee.save()
            messages.success(request, 'Profile picture updated!')

        return redirect('employee_profile')

    # Chart Data Preparation
    dates = [a.date.strftime("%Y-%m-%d") for a in attendances]
    statuses = ["Present" if a.check_in else "Absent" for a in attendances]
    attendance_values = [1 if a.check_in else 0 for a in attendances]

    return render(request, 'employees/profile.html', {
        'employee': employee,
        'leave_requests': leave_requests,
        'attendances': attendances,
        'dates': dates,
        'statuses': statuses,
        'attendance_values': attendance_values
    })

@login_required
def admin_leave_response(request, leave_id):
    if not request.user.is_superuser:
        return redirect('home')
    
    leave = LeaveRequest.objects.get(id=leave_id)
    
    if request.method == 'POST':
        response = request.POST.get('admin_response')
        leave.admin_response = response
        leave.save()
        messages.success(request, 'Response Submitted!')
    
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="Leave_Response_{leave_id}.pdf"'
    
    p = canvas.Canvas(response)
    p.drawString(100, 800, f"Leave ID: {leave_id}")
    p.drawString(100, 780, f"Employee: {leave.employee.user.username}")
    p.drawString(100, 760, f"Status: {leave.status}")
    p.drawString(100, 740, f"Admin Response: {leave.admin_response}")
    p.showPage()
    p.save()
    
    return response


@login_required
def download_response(request, leave_id):
    leave = LeaveRequest.objects.get(id=leave_id)
    if not request.user.is_superuser and leave.employee.user != request.user:
        return HttpResponse("Unauthorized", status=401)
        
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="Leave_Response_{leave_id}.pdf"'
    
    p = canvas.Canvas(response)
    p.drawString(100, 800, f"Leave Response Document")
    p.drawString(100, 760, f"Leave ID: {leave_id}")
    p.drawString(100, 740, f"Employee: {leave.employee.user.get_full_name() or leave.employee.user.username}")
    p.drawString(100, 720, f"Employee ID: {leave.employee.employee_id}")
    p.drawString(100, 700, f"Position: {leave.employee.position} ({leave.employee.department})")
    p.drawString(100, 660, f"Start Date: {leave.start_date}")
    p.drawString(100, 640, f"End Date: {leave.end_date}")
    p.drawString(100, 620, f"Reason: {leave.reason}")
    p.drawString(100, 580, f"Status: {leave.status}")
    p.drawString(100, 560, f"Salary Deduction: {leave.salary_deduction}")
    p.drawString(100, 540, f"Admin Response: {leave.admin_response or 'N/A'}")
    p.showPage()
    p.save()
    
    return response


@login_required
def view_leaves(request):
    if not request.user.is_superuser:
        return redirect('home')
        
    status_filter = request.GET.get('status', '')
    query = request.GET.get('q', '')
    
    leaves = LeaveRequest.objects.all().order_by('-created_at')
    
    if status_filter:
        leaves = leaves.filter(status=status_filter)
    if query:
        leaves = leaves.filter(
            Q(employee__employee_id__icontains=query) |
            Q(employee__user__username__icontains=query) |
            Q(employee__user__first_name__icontains=query) |
            Q(employee__user__last_name__icontains=query)
        )
        
    return render(request, 'employees/view_leaves.html', {
        'leaves': leaves,
        'status_filter': status_filter,
        'query': query
    })


@login_required
def approve_leave(request, leave_id):
    if not request.user.is_superuser:
        return redirect('home')
        
    leave = LeaveRequest.objects.get(id=leave_id)
    leave.status = 'Approved'
    
    duration = (leave.end_date - leave.start_date).days + 1
    leave.salary_deduction = (leave.employee.salary / 30) * duration
    leave.save()
    
    messages.success(request, f"Leave approved for {leave.employee.user.username}. Salary deduction: {leave.salary_deduction:.2f}")
    return redirect('view_leaves')


@login_required
def reject_leave(request, leave_id):
    if not request.user.is_superuser:
        return redirect('home')
        
    leave = LeaveRequest.objects.get(id=leave_id)
    leave.status = 'Rejected'
    
    if request.method == 'POST':
        admin_response = request.POST.get('admin_response', '')
        leave.admin_response = admin_response
        
    leave.save()
    messages.success(request, f"Leave request rejected for {leave.employee.user.username}.")
    return redirect('view_leaves')


@login_required
def ai_insights(request):
    employees = Employee.objects.all()
    attendances = Attendance.objects.all()
    leaves = LeaveRequest.objects.all()
    
    total_employees = employees.count()
    total_attendances = attendances.count()
    approved_leaves = leaves.filter(status='Approved').count()
    
    distinct_dates_count = Attendance.objects.values('date').distinct().count()
    if distinct_dates_count > 0 and total_employees > 0:
        overall_attendance_rate = min(100.0, round((total_attendances / (total_employees * distinct_dates_count)) * 100, 1))
    else:
        overall_attendance_rate = 0.0
        
    trend_direction = "Stable"
    trend_slope = 0.0
    forecast_next_rate = overall_attendance_rate
    
    today = timezone.now().date()
    last_14_days = [today - timedelta(days=i) for i in range(13, -1, -1)]
    
    x_vals = []
    y_vals = []
    
    for idx, day in enumerate(last_14_days):
        day_att = Attendance.objects.filter(date=day).count()
        if total_employees > 0:
            rate = (day_att / total_employees) * 100
            x_vals.append(idx)
            y_vals.append(rate)
            
    n = len(x_vals)
    if n > 1:
        sum_x = sum(x_vals)
        sum_y = sum(y_vals)
        sum_xy = sum(x * y for x, y in zip(x_vals, y_vals))
        sum_xx = sum(x * x for x in x_vals)
        
        denominator = (n * sum_xx - sum_x * sum_x)
        if denominator != 0:
            trend_slope = (n * sum_xy - sum_x * sum_y) / denominator
            
        if trend_slope > 0.5:
            trend_direction = "Increasing"
        elif trend_slope < -0.5:
            trend_direction = "Decreasing"
            
        intercept = (sum_y - trend_slope * sum_x) / n
        forecast_next_rate = min(100.0, max(0.0, round(trend_slope * n + intercept, 1)))
        
    burnout_alerts = []
    for emp in employees:
        emp_att_dates = Attendance.objects.filter(employee=emp, date__gte=today - timedelta(days=10)).values_list('date', flat=True).distinct()
        emp_att_dates = sorted(list(emp_att_dates))
        
        consecutive = 0
        max_consecutive = 0
        if emp_att_dates:
            prev_date = emp_att_dates[0]
            consecutive = 1
            max_consecutive = 1
            for d in emp_att_dates[1:]:
                if (d - prev_date).days == 1:
                    consecutive += 1
                else:
                    consecutive = 1
                max_consecutive = max(max_consecutive, consecutive)
                prev_date = d
                
        emp_long_shifts = 0
        emp_shifts = Attendance.objects.filter(employee=emp, date__gte=today - timedelta(days=14), check_in__isnull=False, check_out__isnull=False)
        for s in emp_shifts:
            duration_hours = (s.check_out - s.check_in).total_seconds() / 3600
            if duration_hours > 10:
                emp_long_shifts += 1
                
        if max_consecutive > 5 or emp_long_shifts > 2:
            risk_reason = []
            if max_consecutive > 5:
                risk_reason.append(f"Worked {max_consecutive} consecutive days")
            if emp_long_shifts > 2:
                risk_reason.append(f"Logged {emp_long_shifts} long shifts (>10h) recently")
            burnout_alerts.append({
                'employee': emp,
                'reasons': ", ".join(risk_reason),
                'risk_level': "High" if (max_consecutive > 6 or emp_long_shifts > 4) else "Medium"
            })
            
    weekday_attendance = {0: [], 1: [], 2: [], 3: [], 4: [], 5: [], 6: []}
    all_att = Attendance.objects.all()
    for att in all_att:
        weekday = att.date.weekday()
        weekday_attendance[weekday].append(att)
        
    weekday_rates = {}
    weekdays_names = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    
    slump_day = None
    min_rate = 101.0
    
    for wd in range(5):
        att_count = Attendance.objects.filter(date__week_day=wd+2).count()
        distinct_days = Attendance.objects.filter(date__week_day=wd+2).values('date').distinct().count()
        if distinct_days > 0 and total_employees > 0:
            rate = round((att_count / (total_employees * distinct_days)) * 100, 1)
            weekday_rates[weekdays_names[wd]] = rate
            if rate < min_rate:
                min_rate = rate
                slump_day = weekdays_names[wd]
        else:
            weekday_rates[weekdays_names[wd]] = 0.0
            
    absence_predictions = []
    for emp in employees:
        emp_leaves = LeaveRequest.objects.filter(employee=emp, status='Approved', start_date__gte=today - timedelta(days=90))
        total_leave_days = sum((l.end_date - l.start_date).days + 1 for l in emp_leaves)
        
        monthly_avg = total_leave_days / 3.0
        probability = min(95.0, round((monthly_avg / 22.0) * 100, 1))
        if probability < 5:
            probability = 5.0
            
        absence_predictions.append({
            'employee': emp,
            'probability': probability,
            'risk': "High" if probability > 40 else ("Medium" if probability > 15 else "Low")
        })
        
    absence_predictions = sorted(absence_predictions, key=lambda x: x['probability'], reverse=True)
    
    ai_recommendations = []
    for dept in employees.values_list('department', flat=True).distinct():
        dept_emps = employees.filter(department=dept)
        active_leaves_next_week = LeaveRequest.objects.filter(
            employee__department=dept,
            status='Approved',
            start_date__lte=today + timedelta(days=7),
            end_date__gte=today
        ).count()
        
        if dept_emps.count() > 0:
            leave_ratio = active_leaves_next_week / dept_emps.count()
            if leave_ratio >= 0.3:
                ai_recommendations.append({
                    'category': "Staffing Risk",
                    'title': f"Understaffing in {dept} Department",
                    'description': f"{active_leaves_next_week} employees in {dept} have approved leaves next week, reducing active staff by {round(leave_ratio*100)}%. Consider pausing new deliverables or hiring temporary staff.",
                    'severity': "Danger"
                })
                
    if slump_day and min_rate < 80:
        ai_recommendations.append({
            'category': "Workforce Slump",
            'title': f"Attendance Drop on {slump_day}s",
            'description': f"Attendance drops to {min_rate}% on {slump_day}s. We suggest scheduling team check-ins or major releases on mid-week days (Tuesday-Thursday).",
            'severity': "Warning"
        })
        
    if burnout_alerts:
        high_risk_burnouts = [b for b in burnout_alerts if b['risk_level'] == 'High']
        if high_risk_burnouts:
            names = ", ".join([b['employee'].user.username for b in high_risk_burnouts[:3]])
            ai_recommendations.append({
                'category': "Burnout Risk",
                'title': "High Burnout Risk Alert",
                'description': f"Employees ({names}) are exhibiting signs of severe burnout due to overtime or consecutive days. Recommend offering mandatory off-days.",
                'severity': "Danger"
            })
            
    if not ai_recommendations:
        ai_recommendations.append({
            'category': "General Optimization",
            'title': "Workforce is stable",
            'description': "AI models detect steady attendance trends and normal workload distributions across all departments.",
            'severity': "Info"
        })
        
    dept_distribution = Employee.objects.values('department').annotate(count=Count('id'))
    dept_labels = [d['department'] for d in dept_distribution]
    dept_counts = [d['count'] for d in dept_distribution]
    
    return render(request, 'employees/ai_insights.html', {
        'total_employees': total_employees,
        'overall_attendance_rate': overall_attendance_rate,
        'trend_direction': trend_direction,
        'trend_slope': round(trend_slope, 2),
        'forecast_next_rate': forecast_next_rate,
        'burnout_alerts': burnout_alerts,
        'weekday_rates': weekday_rates,
        'absence_predictions': absence_predictions[:5],
        'ai_recommendations': ai_recommendations,
        'dept_labels': dept_labels,
        'dept_counts': dept_counts
    })