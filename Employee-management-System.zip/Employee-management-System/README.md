# Employee Management System (EMS)

This is a Django-based Employee Management System with employee record management, attendance tracking, leave requests, and AI insights.

## Features

- Add, update, delete, and view employees
- Search and filter employees by ID, name, department, and position
- Attendance check-in/check-out and attendance log
- Leave request submission, approval, rejection, and PDF response download
- AI insights dashboard with attendance trends, burnout risk, and absence predictions
- Clean responsive UI built with Bootstrap styles

## Installation

1. Clone the repository:
   ```bash
   git clone https://github.com/muhammad-hassn/Employee-management-System.git
   cd Employee-management-System
   ```

2. Create and activate a virtual environment:
   ```bash
   python -m venv venv
   venv\Scripts\activate
   ```

3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

4. Run migrations:
   ```bash
   python manage.py makemigrations
   python manage.py migrate
   ```

5. Create a superuser for admin access:
   ```bash
   python manage.py createsuperuser
   ```

6. Start the development server:
   ```bash
   python manage.py runserver
   ```

7. Open the application in a browser:
   - Login: `http://127.0.0.1:8000/login/`
   - Employee profile: `http://127.0.0.1:8000/profile/`
   - AI insights: `http://127.0.0.1:8000/ai-insights/`

## Notes

- Employee accounts can be created by the admin using the Add Employee page.
- AI insights are available to all logged-in users.
- Do not commit `db.sqlite3`, uploaded `media/` files, or local virtual environment files.
